document.getElementById('notify-btn').addEventListener('click', function() {
    const notification = document.getElementById('notification');
    notification.textContent = '🎉 Membro 2 foi essencial em cada projeto, trazendo inovação e eficiência, além de inspirar toda a equipe com suas ideias visionárias! 🚀';
    notification.style.display = 'block'; 
    notification.classList.add('fade-in'); 

    
    setTimeout(() => {
        notification.classList.remove('fade-in'); 
        notification.style.display = 'none'; 
    }, 5000);
});
