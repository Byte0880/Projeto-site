document.getElementById('notify-btn').addEventListener('click', function() {
    const notification = document.getElementById('notification');
    notification.textContent = '🚀 Membro 1 foi peça-chave no sucesso dos projetos, sempre entregando soluções inovadoras e colaborando com entusiasmo! 🌟';
    notification.style.display = 'block'; 
    notification.classList.add('fade-in'); 

    
    setTimeout(() => {
        notification.classList.remove('fade-in'); 
        notification.style.display = 'none'; 
    }, 5000);
});
